# Code of Conduct

This repository, being work of the 
[World Wide Web Consortium (W3C)](https://www.w3.org/), is subject to the 
[W3C Code of Ethics and Professional Conduct](https://www.w3.org/Consortium/cepc/).

